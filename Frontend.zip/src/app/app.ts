import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Loader } from './core/layouts/loader/loader';

@Component({
  imports: [
    RouterOutlet,
    Loader
  ],
  selector: 'app-root',
  styleUrl: './app.scss',
  templateUrl: './app.html',
})
export class App {}
